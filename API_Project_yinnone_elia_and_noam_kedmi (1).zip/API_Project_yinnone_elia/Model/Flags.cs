﻿namespace API_Project_yinnone_elia.Model
{
    public class Flags
    {
        public string Svg { get; set; }
        public string Png { get; set; }
    }
}

﻿using System.Diagnostics.Metrics;
using System.Text.Json;
using API_Project_yinnone_elia.Model;


namespace API_Project_yinnone_elia.Services
{
    public class CountryService
    {
        private readonly HttpClient _httpClient;

        public CountryService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<Country>> GetAllCountriesAsync()
        {
            string url = "https://restcountries.com/v2/all?fields=name,capital,region";
            string fields = "name,capital,region,flags,population,nativeName,area";
            var response = await _httpClient.GetAsync($"{url}?fields={fields}");
            response.EnsureSuccessStatusCode();

            var jsonString = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };

            return JsonSerializer.Deserialize<List<Country>>(jsonString, options);
        }
    }
}
﻿namespace API_Project_yinnone_elia.Model
{
    public class Country
    {
        public string Name { get; set; }
        public string Capital { get; set; }
        public string Region { get; set; }
        public int Population { get; set; }
        public Flags Flags { get; set; }
        public string NativeName { get; set; }

        public double Area { get; set; }

    }
}